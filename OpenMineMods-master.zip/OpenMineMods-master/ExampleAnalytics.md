The following is all the data collected.
You can view the server code [here](https://github.com/joonatoona/OpenMineMods_Analytics), and the code that sends data to the server [here](https://github.com/joonatoona/OpenMineMods/blob/master/Utils/Analytics.py)

```
TIMESTAMP: 1505221402316
VERSION: '1.0.1'
COUNTRY: 'FI'
LAST OCTLET OF IP: 87
UUID: '6e300ac8-e0f6-4848-9668-bebfac0dfbc4'
MULTIMC FOLDER: '/home/{USER}/.local/share/multimc'
OPENMINEMODS FOLDER: '/home/{USER}/src/OpenMineMods'
SYSTEM: 'Linux 4.10.0-33-generic (x86_64)'
```