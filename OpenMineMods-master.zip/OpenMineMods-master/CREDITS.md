# Translators:

Dutch translations provided by [Jef Willems](https://github.com/Jefwillems)
Italian translations provided by [Antonio Spada] (https://github.com/Brain888)