ls dist/OpenMineMods
